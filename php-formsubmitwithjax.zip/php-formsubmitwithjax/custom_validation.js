//******************************AD Detail sender   validation  start Here*****************************//.

$(document).ready(function(e) {
	
	$('#submit_digital').click(function(e) {
		e.preventDefault();
		//alert('hello');
$("#error_msg").css('color','red');
		
				 $name = $('#name').val();
		        $email = $('#email').val();
				$mobile_no=$('#mobile_no').val();
				$project_info=$('#project_info').val();
				
				
				//alert($send_me_cpoyad);

				 var emailRegex = new RegExp(/^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$/i);
 			     var valid = emailRegex.test($email);
		

		var regexp = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/
        var valid2=regexp.test($phone);
				
				 if($name == "")
				 {
					$('#error_msg').html("Please Enter Your Name");
					$('#name').focus();
				 }
				
				  else  if($email == "")
				 {
					$('#error_msg').html("Please Enter Email Id");
					$('#email').focus();
				 }
				
				else  if(!valid)
				{
					$('#error_msg').html("Please Enter Valid Email Id");
					$('#email').focus();
				 }
				 
				 else if($mobile_no == "")
				 {
					$('#error_msg').html("Please Enter Phone Number  ");
					$('#mobile_no').focus();
				 }

				   else if(isNaN($mobile_no))
				 {
					$('#error_msg').html("Please Enter Phone Number  ");
					$('#mobile_no').focus();
				 }
				 
				else if($project_info == "")
				{	
					$('#error_msg').html("Please enter message");
					$('#project_info').focus();
				}
				 
				 else
				{
					$('#error_msg').html(null);
				
				$.ajax({
					type: "POST",
					cache: false,
					url: "send-contact-mail.php",
					data: 'email='+ $email +'&name='+$name +'&mobile_no='+$mobile_no+'&project_info='+$project_info,
					success: function(data) {
						$("#error_msg").css('color','green');
						$("#error_msg").html(data);
						$("#name").val(null);
						$("#email").val(null);
						$("#mobile_no").val(null);
						$("#project_info").val(null);
					}
				});
				
				}
								
	});
});
//******************************end AD Detail validation  ends Here*****************************//.



