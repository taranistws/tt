$('#explore-courses').click(function () {
   $(this).hide();
   $('#courses').show();
});


$(function() {
  $("#search-institutes").autocomplete({
    source: "api/get_search/",
    minLength: 2,
    select: function(event, ui) {
            var url = ui.item.goto_url;
            if(url != '#') {
                location.href = url;
            }
    },
     response: function(event, ui) {
        if (!ui.content.length) {
            var noResult = {
                value:"",
                label:"No results found. Explore all courses.",
                "goto_url": "/institutes/"
            };
            ui.content.push(noResult);
        }
    }
  });
});


$('#submit-ratings').click(function () {
    $('#rating-form').submit();
});